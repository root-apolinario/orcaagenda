// Optional server extension. The current UI uses the same deterministic rules locally,
// so no AI provider or secret is required to operate reservations, demos, or messages.
// If an AI provider is added later, keep its key in Supabase secrets and validate its output
// as untrusted draft data before showing it to an administrator.

Deno.serve(async (request) => {
  if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  try {
    const body = await request.json() as { text?: unknown };
    if (typeof body.text !== 'string' || body.text.length > 3000) return Response.json({ error: 'Texto inválido.' }, { status: 400 });
    return Response.json({
      draft: {
        text: body.text,
        status: 'rascunho_editavel',
        warning: 'Não tratar o texto como dado confirmado. Revise nome, cidade, serviços, preços, duração, contatos e regras antes de ativar.',
        missing: ['nome confirmado', 'cidade confirmada', 'serviços', 'preços', 'duração', 'contatos', 'horários'],
      },
    });
  } catch {
    return Response.json({ error: 'Não foi possível preparar o rascunho.' }, { status: 400 });
  }
});
